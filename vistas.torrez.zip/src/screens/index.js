export { default as Categories } from "./categories/index";
export { default as Products } from "./products/index";
export { default as ProductDetail } from "./product-detail/index";