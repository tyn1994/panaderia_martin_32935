import { Text, View } from "react-native";

import React from "react";
import { styles } from "./styles";

const ProductDetail = () => {
    return (
        <View style={styles.container} >
            <Text>ProductDetail</Text>
        </View>
    )
}

export default ProductDetail;